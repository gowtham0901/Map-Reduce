Assignament-6
#Roll:21CS60R29
#Name:Banavathula Gowtham Naik

Query1:
run:
cat network.txt | python mapper.py | sort | python reducer.py > result.txt




Query2:

run:

cat network.txt | python mapper.py | sort | python reducer.py > result.txt


Query3:

cat network.txt | python mapper.py | sort | python reducer.py > result.txt

Query4:

run:

python3 mapper.py | sort | python3 reducer.py >result.txt
 